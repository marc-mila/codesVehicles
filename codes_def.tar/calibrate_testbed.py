import json
print(json.dumps({"message" : "TestBed calibrated successfully"}))
